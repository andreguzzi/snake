package br.com.game.snake;

import br.com.game.snake.core.Game;

public class Aplication {
	
	public static void main(String[] args) {
		new Game().start();
	}
}
