package br.com.game.snake.graphics;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class Renderer {
	
	private List<Drawable> drawables;
	private Graphics g;
	
	public Renderer(Graphics g) {
		drawables = new ArrayList<>();
		this.g = g;
	}
	
	public synchronized void render() {
		for (Drawable d : drawables) {
			g.setColor(d.getColor());
			d.draw(g);
		}
	}
	
	public synchronized void add(Drawable d) {
		drawables.add(d);
	}

	public synchronized void remove (Drawable d) {
		drawables.remove(d);
	}
}
