package br.com.game.snake.scense;

import br.com.game.snake.graphics.Text;

import static br.com.game.snake.util.Constants.GAME_OVER_COLOR;
import static br.com.game.snake.util.Constants.GAME_OVER_TEXT;
import static br.com.game.snake.util.Constants.GAME_OVER_LOCATION;

public class GameOverText extends Text{
	
	public GameOverText(int score) {
		super (GAME_OVER_COLOR, String.format(GAME_OVER_TEXT,score), GAME_OVER_LOCATION);
	}

}
